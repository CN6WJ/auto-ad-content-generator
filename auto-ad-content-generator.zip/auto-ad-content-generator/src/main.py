from text_generator import TextGenerator
from image_generator import ImageGenerator
from video_generator import VideoGenerator

def main():
    prompt = input("Enter the ad idea: ")
    text_generator = TextGenerator()
    image_generator = ImageGenerator()
    video_generator = VideoGenerator()

    # Generate ad content
    ad_text = text_generator.generate_text(prompt)
    ad_image = image_generator.generate_image(ad_text)
    ad_video = video_generator.generate_video(ad_image)

    print(f"Generated Ad Text: {ad_text}")
    # Optionally save generated content
    print(f"Image saved as: {ad_image}")
    print(f"Video saved as: {ad_video}")

if __name__ == "__main__":
    main()